#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <EEPROM.h>
#include <ESPAsyncTCP.h>

#include <ESPAsyncWebServer.h>
// Variables
int i = 0;
int statusCode;
const char *ssid = "text";
const char *passphrase = "text";

// Change this parameters  for your project
const char *defaultSSID = "DefaultSSID";
const char *defaultPassword = "defaultadmin";

const char *loginName = "admin";
const char *loginPassword = "admin";

bool isLoggedin = false;

String st;
String content;

// Function Decalration
bool testWifi(void);
void launchWeb(void);
void setupAP(void);
void setupServer(void);
void scanNetworks();
void deviceinfo(AsyncWebServerRequest *request);
void appendNetworks(AsyncWebServerRequest *request);

#pragma region HTMLFILES
#pragma region indexHTML

const char index_html[] PROGMEM = R"rawliteral(
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>LifeTrack Health Monitor - Local</title>
  </head>
  <style>
    :root {
      --light-mode: #eee;
      --darkmode: #d1e9f9;
    }

    html {
      font-size: 10px;
    }

    body {
      font-family: "Sans", sans-serif;
      min-height: 100vh;
      background: var(--darkmode);
      padding: 0;
      margin: 0;
      box-sizing: border-box;
      line-height: 2rem;
    }

    a {
      text-decoration: none;
    }

    .wrapper {
      width: 80%;
      margin-left: auto;
      margin-right: auto;
    }

    nav {
      display: flex;
      font-family: "" Segoe UI ", Tahoma, Geneva, Verdana", sans-serif;
      background-color: #0099dd;
      color: #fff;
      margin-top: 5px;
      margin-bottom: -10px;
      padding: 20px;
      filter: drop-shadow(12px 12px 10px #a1c7e0);
      border-radius: 25px;
    }

    .life,
    .track {
      width: 60px;
      font-size: 4rem;
      color: #fff;
      -webkit-text-stroke-width: 1px;
      -webkit-text-stroke-color: black;
    }

    .track {
      color: #44f9e4;
    }

    #logo-box {
      width: 180px;
      text-align: center;
    }

    #logo-box .logo-link {
      font-weight: 700;
      color: #fff;
    }

    .features {
      padding: 50px 0;
    }

    .features-row {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-around;
      width: 100%;
      margin-bottom: 30px;
    }
    .features-col {
      width: 100%;
      flex-basis: 100%;
      text-align: left;
      filter: drop-shadow(12px 12px 10px #a1c7e0);
      border-radius: 25px;
      z-index: -1;
    }

   
    .features-col h4 {
      margin-bottom: 15px;
      font-size: 24px;
      color: #fff;
      padding: 0 20px;
      width: auto;
    }

    .features-col p {
      font-size: 16px;
      color: #fff;
      color: #fff;
      padding: 0 20px;
      width: auto;
    }

    #chart {
      width: 100%;
    }

    .temperature {
      flex-basis: 25%;
      text-align: left;
      filter: drop-shadow(12px 12px 10px #a1c7e0);
      background-color: #ff4858;
    }

    .humidity {
      flex-basis: 25%;
      text-align: left;
      filter: drop-shadow(12px 12px 10px #a1c7e0);
      background-color: #13678a;
    }

    .valueLabels {
      font-size: 40px;
      background-color: #fff;
      color: brown;
      padding: 40px;
      text-align: center;
    }

    .information{
      flex-basis: 25%;
      text-align: left;
      justify-content: space-around;
      filter: drop-shadow(12px 12px 10px #a1c7e0);
      background-color: #3d332b;
    }

    .infoLines{
      font-size: 20px;
      background-color: #fff;
      color: brown;
      padding: 40px;
      text-align: left;
   }

   li{
    list-style: none;
   }
   a{
    color: white;
    text-decoration: none;
   }
   .navbar{
    min-height: 70px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 24px;
   }

   .nav-menu{
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap:60px;
   }

   .nav-link{
    transition: 0.7s ease;
   }

   .nav-link:hover{
    color:black;
   }
   .hamburger{
    display: none;
    cursor: pointer;
   }
   .bar{
    display: block;
    width: 25px;
    height: 3px;
    margin: 5px auto;
    -webkit-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
    background-color: #fff;
   }

   @media(max-width:768px){
    .hamburger{
        display: block;
    }
    .hamburger.active .bar:nth-child(2){
        opacity: 0;
    }
    .hamburger.active .bar:nth-child(1){
        transform:translateY(8px) rotate(45deg);
    }
    .hamburger.active .bar:nth-child(3){
        transform:translateY(-8px) rotate(-45deg);
    }
    .nav-menu{
        position: fixed;
        left:-200%;
        top:70px;
        gap:0;
        flex-direction: column;
        background-color:dodgerblue ;
        width: 100%;
        text-align: center;
        transition: 0.3s;
        z-index:2!important;
    }

    .nav-item{
        margin: 16px 0;
    }

    .nav-menu.active{
        left: 0;
        z-index: 2;
    }
   }

   

  </style>
  <body>
    <div class="">
      <header>
        <nav class="navbar">
            <a href="/" class="navbar-branding"><span class="life">Life</span>
                <span class="track"><strong>Track</strong></a>
                    <ul class="nav-menu">
                        <li class="nav-item">
                            <a href='scan' class="nav-link">WiFi Networks</a>
                        </li>
                        <li class="nav-item">
                            <a href="#informationArea" class="nav-link">Device Information</a>
                        </li>
                        <li class="nav-item">
                            <a href='logout' class="nav-link">Logout</a>
                        </li>
                    </ul>
                    <div class="hamburger">
                        <span class="bar"></span>
                        <span class="bar"></span>
                        <span class="bar"></span>
                    </div>
        </nav>
      </header>
      <section class="features">
        <div class="features-row">
          <div class="features-col temperature">
            <h4>Ambient Temperature</h4>
            <p>Temperature Value</p>
            <div>
              <div class="valueLabels">
                <label id="temp">%TEMPERATURE%</label>
                <label>°C</label>
              </div>
            </div>
          </div>
        </div>
        <div class="features-col humidity">
            <h4>Ambient Humidity Rate</h4>
            <p>Humidity Value</p>
            <div>
              <div class="valueLabels">
                <label id="hum">%HUMIDITY%</label>
                <label>%</label>
              </div>
            </div>
        <div class="features-row" id="informationArea">
            <div class="features-col information">
              <h4>Device Information</h4>
              <div>
                <div class="infoLines">
                {PLACEHOLDER}
                  
                </div>
              </div>
            </div>
            
          </div>
      </section>
    </div>
  </body>
</html>

<script>
  if (!!window.EventSource) {
    var source = new EventSource("/events");

    source.addEventListener(
      "open",
      function (e) {
        console.log("Events Connected");
      },
      false
    );
    source.addEventListener(
      "error",
      function (e) {
        if (e.target.readyState != EventSource.OPEN) {
          console.log("Events Disconnected");
        }
      },
      false
    );

    source.addEventListener(
      "message",
      function (e) {
        console.log("message", e.data);
      },
      false
    );

    source.addEventListener(
      "pulse",
      function (e) {
        console.log("pulse", e.data);
        document.getElementById("pulse").innerHTML = e.data;
      },
      false
    );

    source.addEventListener(
      "temperature",
      function (e) {
        console.log("temperature", e.data);
        document.getElementById("temp").innerHTML = e.data;
      },
      false
    );

    source.addEventListener(
      "humidity",
      function (e) {
        console.log("humidity", e.data);
        document.getElementById("hum").innerHTML = e.data;
      },
      false
    );

    source.addEventListener(
      "patient",
      function (e) {
        console.log("patient", e.data);
        document.getElementById("patient").innerHTML = e.data;
      },
      false
    );
  }
</script>

<script>
    const hamburger=document.querySelector(".hamburger");
    const navMenu=document.querySelector(".nav-menu");

    hamburger.addEventListener("click",()=>{
        hamburger.classList.toggle("active");
        navMenu.classList.toggle("active");
    });

    document.querySelector(".nav-link").array.forEach(n => {
        n.addEventListener("click",()=>{
            hamburger.classList.remove("active");
            navMenu.classList.remove("active");
        })
    });
</script>

)rawliteral";
#pragma endregion
#pragma region loginHTML
const char login_html[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="tr_TR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style type="text/css">

*:where(:not(html, iframe, canvas, img, svg, video):not(svg *, symbol *)) {
    display: revert;
}


*,
*::before,
*::after {
    box-sizing: border-box;
}




input, textarea {
    -webkit-user-select: auto;
}


textarea {
    white-space: revert;
}


meter {
    -webkit-appearance: revert;
    appearance: revert;
}

::placeholder {
    color: unset;
}


:where([hidden]) {
    display: none;
}



body {
    font-family: 'Sans', sans-serif;
    min-height: 100vh;
    background: linear-gradient(#A1C7E0, #fff);
    display: flex;
    justify-content: center;
    align-items: center;
    filter:drop-shadow(12px 12px 10px #A1C7E0)
}


.login-card {
    width: 450px;
    background: rgba(255, 255, 255, 0.5);
    padding: 4rem;
    border-radius: 10px;
    position: relative;
}
.login-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(255, 255, 255, .15);
    transform: rotate(-6deg);
    border-radius: 10px;
    z-index: -1;
}

.login-card-logo {
    display: flex;
    margin-bottom: 2rem;
    text-align: center;
}

 .life {
    width: 60px;
    font-size: 38px;
    color: #fff;
    outline: black 1px;
    -webkit-text-stroke-width: 1px;
    -webkit-text-stroke-color: black;
}

.track {
    width: 60px;
    font-size: 38px;
    color: #44f9e4;
    -webkit-text-stroke-width: 1px;
    -webkit-text-stroke-color: black;
}

.login-card-logo,
.login-card-header,
.login-card-footer {
    text-align: center;
}

.login-card-header h1 {
    font-size: 28px;
    font-weight: 600;
    margin-bottom: .5rem;
}

.login-card-header h1+div {
    font-size: calc(1rem * .8);
    opacity: .8;
}


.login-card-form .form-item {
    position: relative;
}

.login-card-form .form-item .form-item-icon {
    position: absolute;
    top: .82rem;
    left: 1.4rem;
    font-size: 1.3rem;
    opacity: .4;
}



.login-card input[type="text"],
.login-card input[type="password"] {
    border: none;
    outline: none;
    margin: 10px;
    background: rgba(255, 255, 255, .3);
    padding: 1rem 1.5rem;
    padding-left: calc(1rem * 3.5);
    border-radius: 100px;
    width: 100%;
    transition: background .5s;
}

.login-card input:focus {
    background: white;
}

.login-card button {
    background: black;
    color: white;
    padding: 1rem;
    border-radius: 100px;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 2px;
    transition: background .5s;
}

.login-card button:hover {
    background-color: rgba(0, 0, 0, 0.85);
    cursor: pointer;
}

@media (max-width: 768px) {

   body {
        padding: 2rem 0;
    }

    .login-card {
        width: 280px;
        padding: 2rem;
    }
}

    </style>
    <title>LifeTrack Login Page</title>
</head>
<body>
    <div class="login-card-container">
        <div class="login-card">
            <div class="lifetrack-logo">
                <span class="life">Life</span>
                <span class="track"><strong>Track</strong></span>
            </div>
            <div class="login-card-header">
                <h1>Welcome Login Screen</h1>
            </div>
            <form class="login-card-form" method='get' action='login'>
                <div class="form-item">
                    <input type="text" name='username' placeholder="Enter Username" id="username"  autofocus required>
                </div>
                <div class="form-item">
                    <input type="password" name ='passwordForm' placeholder="Enter Password" id="passwordForm"
                     required>
                </div>               
                <button type="submit">LOGIN</button>
            </div>
            </form>
        </div>
    </div>
</body>
</html>)rawliteral";
#pragma endregion // Login.html ends
#pragma region scanHtml
const char scan_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Networks</title>
</head>

<body>
    <div>
        <header>
            <nav class="navbar">
                <a href="/" class="navbar-branding"><span class="life">Life</span>
                    <span class="track"><strong>Track</strong></a>
                        <ul class="nav-menu">
                            <li class="nav-item">
                                <a href='scan' class="nav-link">WiFi Networks</a>
                            </li>
                            <li class="nav-item">
                                <a href="/" class="nav-link">Device Information</a>
                            </li>
                            <li class="nav-item">
                                <a href='logout' class="nav-link">Logout</a>
                            </li>
                        </ul>
                        <div class="hamburger">
                            <span class="bar"></span>
                            <span class="bar"></span>
                            <span class="bar"></span>
                        </div>
            </nav>
          </header>
          <section class="features">
            <div class="features-row">
              <div class="features-col">
                <h4>Networks Found</h4>
                <p>Please select a SSID and try to join network</p>
                <div>
                  
                    {PLACEHOLDER}

                </div>
              </div>
              </div>
          </section>
    </div>
</body>
<script>
    const hamburger=document.querySelector(".hamburger");
    const navMenu=document.querySelector(".nav-menu");

    hamburger.addEventListener("click",()=>{
        hamburger.classList.toggle("active");
        navMenu.classList.toggle("active");
    });

    document.querySelector(".nav-link").array.forEach(n => {
        n.addEventListener("click",()=>{
            hamburger.classList.remove("active");
            navMenu.classList.remove("active");
        })
    });
</script>
</html>)rawliteral";
#pragma endregion
#pragma endregion

// Establishing Local server at port 80 whenever required
AsyncWebServer server(80);
AsyncEventSource events("/events");

float temperature;
float humidity;
int bpm;
float patient;

// Need a processor to compile event request
String processor(const String &var)
{

  if (var == "TEMPERATURE")
  {
    return String(temperature);
  }
  else if (var == "HUMIDITY")
  {
    return String(humidity);
  }
  else if (var == "HUMIDITY")
  {
    return String(bpm);
  }
  else if (var == "HUMIDITY")
  {
    return String(patient);
  }

  return String();
}

unsigned long sonZaman = 0;
unsigned long beklemeSuresi = 5000;
void setup()
{
  Serial.println();
  Serial.println();
  Serial.println();

  Serial.begin(9600); // Initialising if(DEBUG)Serial Monitor
  Serial.println();
  Serial.println("Disconnecting previously connected WiFi");
  WiFi.disconnect();
  EEPROM.begin(512); // Initialasing EEPROM
  delay(10);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.println();
  Serial.println();
  Serial.println("Startup");

  //---------------------------------------- Read EEPROM for SSID and pass
  Serial.println("Reading EEPROM ssid");

  String esid;
  for (int i = 0; i < 32; ++i)
  {
    esid += char(EEPROM.read(i));
  }
  Serial.println();
  Serial.print("SSID: ");
  Serial.println(esid);
  Serial.println("Reading EEPROM pass");

  String epass = "";
  for (int i = 32; i < 96; ++i)
  {
    epass += char(EEPROM.read(i));
  }
  Serial.print("PASS: ");
  Serial.println(epass);

  WiFi.begin("", "");
  WiFi.begin(esid.c_str(), epass.c_str());
  if (testWifi())
  {
    Serial.println("Succesfully Connected!!!");
    return;
  }
  else
  {
    Serial.println("Turning the HotSpot On");
    launchWeb();
    setupAP(); // Setup HotSpot
  }

  Serial.println();
  Serial.println("There no wifi connection. AP Mode Started.");

  setupServer();

  // server.on("/",[](AsyncWebServerRequest *request){
  //   request->send_P(200,"text/html",index_html,processor);
  // });
  events.onConnect([](AsyncEventSourceClient *client)
                   {
    if(client->lastId()){
      Serial.printf("Client is reconnected : %u\n", client->lastId());
    }
   
    client->send("Hello World!", NULL, millis(), 5000); });

  server.addHandler(&events);
}

void loop()
{
  if ((millis() - sonZaman) > beklemeSuresi)
  { // set random values for temperature and humidity to simulate some values
    temperature = rand() % 20 + 1;
    humidity = rand() % 20 + 1;

    Serial.printf("Sıcaklık = %.2f ºC \n", temperature);
    Serial.printf("Nem = %.2f \n", humidity);
    Serial.println();

    events.send("ping", NULL, millis());
    events.send(String(temperature).c_str(), "temperature", millis());
    events.send(String(humidity).c_str(), "humidity", millis());

    sonZaman = millis();
  }
}

//-------- Fuctions used for WiFi credentials saving and connecting to it which you do not need to change
bool testWifi(void)
{
  int c = 0;
  Serial.println("Waiting for Wifi to connect");
  while (c < 20)
  {
    if (WiFi.status() == WL_CONNECTED)
    {
      return true;
    }
    delay(500);
    Serial.print("*");
    c++;
  }
  Serial.println("");
  Serial.println("Connect timed out, opening AP");
  return false;
}

void launchWeb()
{
  Serial.println("");
  if (WiFi.status() == WL_CONNECTED)
    Serial.println("WiFi connected");
  Serial.print("Local IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("SoftAP IP: ");
  Serial.println(WiFi.softAPIP());
  // createWebServer();
  //  Start the server
  server.begin();
  Serial.println("Server started");
}

void setupAP(void)
{
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);
  scanNetworks();
  delay(100);
  WiFi.softAP(defaultSSID, defaultPassword);
  Serial.println("softap");
  launchWeb();
  Serial.println("over");
}
void scanNetworks()
{
  int n = WiFi.scanNetworks();
  Serial.println("scan done");
  if (n == 0)
    Serial.println("no networks found");
  else
  {
    Serial.print(n);
    Serial.println(" networks found");
    for (int i = 0; i < n; ++i)
    {
      // Print SSID and RSSI for each network found
      Serial.print(i + 1);
      Serial.print(": ");
      Serial.print(WiFi.SSID(i));
      Serial.print(" (");
      Serial.print(WiFi.RSSI(i));
      Serial.print(")");
      Serial.println((WiFi.encryptionType(i) == ENC_TYPE_NONE) ? " " : "*");
      delay(10);
    }
  }
  Serial.println("");
  st = "<ol>";
  for (int i = 0; i < n; ++i)
  {
    // Print SSID and RSSI for each network found
    st += "<li>";
    st += WiFi.SSID(i);
    st += " (";
    st += WiFi.RSSI(i);

    st += ")";
    st += (WiFi.encryptionType(i) == ENC_TYPE_NONE) ? " " : "*";
    st += "</li>";
  }
  st += "</ol>";
}
void setupServer()
{
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
            {
              if (isLoggedin)
              request->send_P(200,"text/html",index_html,processor);
              //  deviceinfo(request);
              else
                request->send(200, "text/html", login_html); });
  server.on("/login", HTTP_GET, [](AsyncWebServerRequest *request)
            {
      String username=request->arg("username");  
      String password=request->arg("passwordForm");
      if(username==loginName&&password==loginPassword){
        isLoggedin=true;
        deviceinfo(request);

      }else{
        request->send(200, "text/html", login_html);
      } });
  server.on("/logout", HTTP_GET, [](AsyncWebServerRequest *request)
            {
      isLoggedin=false;
      request->send(200, "text/html", login_html); });

  server.on("/scan", HTTP_GET, [](AsyncWebServerRequest *request)
            {
              if (isLoggedin)
              {
                scanNetworks();
                appendNetworks(request);
              }
               else
                request->send(200, "text/html", login_html); });

  server.on("/setting", HTTP_GET, [](AsyncWebServerRequest *request)
            {
    if (isLoggedin)
         {
          Serial.println("eeprom");
          String qsid=request->arg("ssid");
          String qpass=request->arg("pass");
          if (qsid.length() > 0 && qpass.length() > 0)
                {
                  Serial.println("clearing eeprom");
                  for (int i = 0; i < 96; ++i)
                  {
                    EEPROM.write(i, 0);
                  }
                  Serial.println(qsid);
                  Serial.println("");
                  Serial.println(qpass);
                  Serial.println("");

                  Serial.println("writing eeprom ssid:");
                  for (int i = 0; i < qsid.length(); ++i)
                  {
                    EEPROM.write(i, qsid[i]);
                    Serial.print("Wrote: ");
                    Serial.println(qsid[i]);
                  }
                  Serial.println("writing eeprom pass:");
                  for (int i = 0; i < qpass.length(); ++i)
                  {
                    EEPROM.write(32 + i, qpass[i]);
                    Serial.print("Wrote: ");
                    Serial.println(qpass[i]);
                  }
                  EEPROM.commit();

                  content = "{\"Success\":\"saved to eeprom... reset to boot into new wifi\"}";
                  statusCode = 200;
                  ESP.reset();
                }
                else
                {
                  content = "{\"Error\":\"404 not found\"}";
                  statusCode = 404;
                  Serial.println("Sending 404");
                }

                request->send(statusCode,"application/json", content);
         } });
}

void deviceinfo(AsyncWebServerRequest *request)
{

  String myDiv = "<span>Mac Address:</span>";
  myDiv += "<span style='color:black;'>";
  myDiv += WiFi.macAddress().c_str();
  myDiv += "</span><br>";
  myDiv += "<span>Local Ip Address:</span>";
  myDiv += "<span style='color:black;'>";
  myDiv += WiFi.softAPIP().toString().c_str();
  myDiv += "</span>";
  String replacedHTML;
  replacedHTML = String(index_html);
  replacedHTML.replace("{PLACEHOLDER}", myDiv);
  request->send(200, "text/html", replacedHTML);
}

void appendNetworks(AsyncWebServerRequest *request)
{

  content = "";
  content += "<p>";
  content += st;
  content += "</p><form action='/setting' method='get'><label>SSID: </label><div class='form-item'><input name='ssid' type='text' id='ssid' length=32></div><div class='form-item'><input name='pass' id='pass' type='password' length=64></div><input type='submit' value='Join'></input></form>";

  String replacedHTML = String(scan_HTML);
  replacedHTML.replace("{PLACEHOLDER}", content);

  request->send(200, "text/html", replacedHTML);
}